package com.hoshmandsakht.efm;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class CustomImageButton extends androidx.appcompat.widget.AppCompatImageButton {

    public CustomImageButton(Context context) {
        super(context);
        init();
    }

    public CustomImageButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomImageButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // Set default properties for your custom button
        setBackgroundResource(R.drawable.c_image_button);

//        setPadding(
//                getResources().getDimensionPixelSize(R.dimen.button_padding_start),
//                getResources().getDimensionPixelSize(R.dimen.button_padding_top),
//                getResources().getDimensionPixelSize(R.dimen.button_padding_end),
//                getResources().getDimensionPixelSize(R.dimen.button_padding_bottom)
//        );

        // Set click listener or any other custom behavior here
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });
    }
}