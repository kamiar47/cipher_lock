package com.hoshmandsakht.efm;

import java.io.File;
import java.util.List;

public interface Option_item_events_listener {
  void Option_item_OnClickListener(List<File> paramList);
  
  void Option_item_OnlongClickListener(List<File> paramList);
}
