package com.hoshmandsakht.efm;

import java.io.File;

public interface File_item_evens_listener {
  void FileItem_onClickListener(File paramFile);
  
  void FileItem_onLongClickListener(File paramFile);
}
