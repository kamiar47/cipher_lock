package com.hoshmandsakht.efm;

import java.io.File;

public interface File_action_event_listener {
  void on_File_about_to_be_processed(File paramFile)throws Throwable;
  
  void on_Overall_progress_changed(int paramInt1, int paramInt2);
}
