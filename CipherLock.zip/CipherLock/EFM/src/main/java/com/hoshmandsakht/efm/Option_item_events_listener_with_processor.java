package com.hoshmandsakht.efm;

import java.io.File;
import java.util.List;

public interface Option_item_events_listener_with_processor extends Option_item_events_listener {
    boolean check_file_list(List<File> files);
}
