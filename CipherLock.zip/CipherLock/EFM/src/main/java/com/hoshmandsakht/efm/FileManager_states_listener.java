package com.hoshmandsakht.efm;

public interface FileManager_states_listener {
  void onFile_Manager_Ready(easyFileManager parameasyFileManager);
  void onFile_manager_backpressed_on_root_dir();
}
